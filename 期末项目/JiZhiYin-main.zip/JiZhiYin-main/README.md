# jizhiyin

## Project setup
```
npm install
npm install element-plus --save
npm install vue-video-player video.js
npm install @fortawesome/fontawesome-free
npm install vue-router
npm install tailwindcss@latest postcss@latest autoprefixer@latest
npx tailwindcss init -p
```

### Compiles and hot-reloads for development
```
npm run serve
```

### Compiles and minifies for production
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://cli.vuejs.org/config/).
