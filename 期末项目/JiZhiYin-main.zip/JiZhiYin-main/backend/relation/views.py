from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import PermissionDenied
from rest_framework.permissions import IsAuthenticated

from interact.serializers import FriendSerializer, GroupSerializer
from relation.serializers import (GroupSelfSerializer, FriendSelfSerializer, GroupPkSerializer,
                                  GroupQuerySerializer, GroupSaveSerializer, GroupDetailSerializer,
                                  RemoveMemberSerializer)
from relation.models import Unread
from notice.models import Notice
from utils.utility import FormatResponse


# Create your views here.

class FriendViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]

    # /relation/friend/list/
    @action(methods=['post'], detail=False)
    def list(self, request):
        friend_serializer = FriendSelfSerializer(
            instance=request.user.friends.all(),
            many=True,
            context={'request': request}
        )
        return FormatResponse(data={
            'friends': friend_serializer.data
        })

    # /relation/friend/delete/
    @action(methods=['post'], detail=False)
    def delete(self, request):
        user = request.user
        serializer = FriendSerializer(instance=user, data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        friend = serializer.validated_data['friend']
        user.friends.remove(friend)
        notice = Notice.objects.create(
            content=f'{user.nickname}解除了与您的好友关系',
            category='好友消息'
        )
        notice.users.set([friend])

        return FormatResponse()


class GroupViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]

    # /relation/group/list/
    @action(methods=['post'], detail=False)
    def list(self, request):
        serializer = GroupSelfSerializer(
            instance=request.user.groups.all(),
            many=True,
            context={'request': request}
        )
        return FormatResponse(data={
            'groups': serializer.data
        })

    # /relation/group/query/
    @action(methods=['post'], detail=False)
    def query(self, request):
        serializer = GroupPkSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        group = serializer.validated_data['group']
        serializer = GroupQuerySerializer(instance=group, context={'request': request})
        return FormatResponse(data=serializer.data)

    # /relation/group/create/
    @action(methods=['post'], detail=False)
    def create(self, request):
        user = request.user
        serializer = GroupSaveSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        group = serializer.save(owner=user, count=1)
        user.groups.add(group)

        # 新建群主和 group 的 Unread
        Unread.objects.create(to_user=user, from_group=group, count=0)
        # name = serializer.validated_data['name']
        # description = serializer.validated_data['description']
        # image_file = serializer.validated_data['image_file']
        # group = UserGroup.objects.create(
        #     name=name,
        #     description=description,
        #     owner=user,
        #     count=1,
        #     image_file=image_file
        # )
        serializer = GroupDetailSerializer(instance=group)
        return FormatResponse(data=serializer.data)

    # /relation/group/update/
    @action(methods=['post'], detail=False)
    def update(self, request):
        serializer = GroupPkSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        group = serializer.validated_data['group']

        if request.user != group.owner:
            raise PermissionDenied('只有群主才能更新信息')

        update_serializer = GroupSaveSerializer(instance=group, data=request.data,
                                                partial=True, context={'request': request})
        update_serializer.is_valid(raise_exception=True)
        group = update_serializer.save()
        group_serializer = GroupDetailSerializer(instance=group, context={'request': request})

        return FormatResponse(data=group_serializer.data)

    # /relation/group/dissolve/
    @action(methods=['post'], detail=False)
    def dissolve(self, request):
        serializer = GroupPkSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        group = serializer.validated_data['group']

        if request.user != group.owner:
            raise PermissionDenied('只有群主才能解散群组')

        notice = Notice.objects.create(
            content=f'{request.user.nickname}解散了群聊{group.name}',
            category='好友消息'
        )
        notice.users.set(group.members.all())

        group.delete()
        return FormatResponse()

    # /relation/group/quit/
    @action(methods=['post'], detail=False)
    def quit(self, request):
        serializer = GroupSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        group = serializer.validated_data['group']

        if group.owner == request.user:
            raise PermissionDenied('群主无法退出群聊只能解散')

        group.count -= 1
        group.save()
        group.members.remove(request.user)
        return FormatResponse()

    # /relation/group/remove/
    @action(methods=['post'], detail=False)
    def remove(self, request):
        serializer = RemoveMemberSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        group = serializer.validated_data['group']
        user = serializer.validated_data['user']

        if not user.groups.filter(pk=group.pk).exists():
            raise PermissionDenied('将要移出的用户未加入该组')

        group.count -= 1
        group.save()
        group.members.remove(user)
        return FormatResponse()
