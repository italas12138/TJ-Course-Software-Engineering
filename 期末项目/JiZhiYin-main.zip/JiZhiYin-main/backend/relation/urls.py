from django.urls import path, include
from relation.views import FriendViewSet, GroupViewSet
from utils.utility import ActionRouter

router = ActionRouter()
router.register(r'friend', FriendViewSet, basename='friend')
router.register(r'group', GroupViewSet, basename='group')

urlpatterns = [
    path('', include(router.urls))
]
