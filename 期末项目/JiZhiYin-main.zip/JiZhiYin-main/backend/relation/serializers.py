from rest_framework import serializers
from rest_framework.exceptions import PermissionDenied

from account.serializers import UserSelfSerializer
from relation.models import Unread
from account.models import UserProfile, UserGroup

from interact.serializers import UserChatSerializer

from utils.utility import primary_key_serializer
from utils.models import UploadFile


class GroupSelfSerializer(serializers.ModelSerializer):
    image_url = serializers.FileField(source='image_file.file', read_only=True, allow_null=True)
    is_owner = serializers.SerializerMethodField()
    unread_count = serializers.SerializerMethodField()

    class Meta:
        model = UserGroup
        fields = ['id', 'name', 'image_url', 'is_owner', 'unread_count']

    def get_is_owner(self, obj):
        user = self.context['request'].user
        return user == obj.owner

    def get_unread_count(self, obj):
        user = self.context['request'].user
        unread = Unread.objects.get(to_user=user, from_group=obj)
        return unread.count


class FriendSelfSerializer(serializers.ModelSerializer):
    image_url = serializers.FileField(source='image_file.file', read_only=True, allow_null=True)
    unread_count = serializers.SerializerMethodField()

    class Meta:
        model = UserProfile
        fields = ['id', 'nickname', 'image_url', 'unread_count']

    def get_unread_count(self, obj):
        user = self.context['request'].user
        unread = Unread.objects.get(to_user=user, from_user=obj)
        return unread.count


GroupPkSerializer = primary_key_serializer('group_id', 'group', UserGroup)


class GroupQuerySerializer(serializers.ModelSerializer):
    is_owner = serializers.SerializerMethodField()
    image_url = serializers.FileField(source='image_file.file', read_only=True, allow_null=True)
    members = UserChatSerializer(many=True, read_only=True)

    class Meta:
        model = UserGroup
        fields = ['id', 'name', 'description', 'count', 'is_owner', 'image_url', 'members']

    def get_is_owner(self, obj):
        user = self.context['request'].user
        return user.id == obj.owner.id


class GroupSaveSerializer(serializers.ModelSerializer):
    image_file_id = serializers.PrimaryKeyRelatedField(source='image_file', queryset=UploadFile.objects.all(),
                                                       allow_null=True)

    class Meta:
        model = UserGroup
        fields = ['name', 'description', 'image_file_id']

    def validate_image_file_id(self, value):
        user = self.context['request'].user
        if value is not None and value.user != user:
            raise PermissionDenied('无法将不是自己上传的文件作为群头像')
        return value


class GroupDetailSerializer(serializers.ModelSerializer):
    image_url = serializers.FileField(source='image_file.file', read_only=True, allow_null=True)

    class Meta:
        model = UserGroup
        fields = ['id', 'name', 'description', 'count', 'image_url']


class RemoveMemberSerializer(serializers.Serializer):
    group_id = serializers.PrimaryKeyRelatedField(source='group', queryset=UserGroup.objects.all())
    user_id = serializers.PrimaryKeyRelatedField(source='user', queryset=UserProfile.objects.all())

    def validate_group_id(self, value):
        user = self.context['request'].user
        if user != value.owner:
            raise PermissionDenied('只有群主可以移出群成员')
        return value
