from django.db import models

from account.models import UserProfile, UserGroup


# Create your models here.
class Unread(models.Model):
    count = models.IntegerField(default=0)
    to_user = models.ForeignKey(UserProfile, on_delete=models.CASCADE,
                                related_name='received_unread_set')
    from_user = models.ForeignKey(UserProfile, on_delete=models.SET_NULL, null=True,
                                  related_name='sent_unread_set')
    from_group = models.ForeignKey(UserGroup, on_delete=models.SET_NULL, null=True,
                                   related_name='sent_unread_set')
