from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import PermissionDenied
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from permission.permissions import IsSuperUser

from account.serializers import UserPkSerializer
from permission.models import Application
from permission.serializers import AdminUpdateSerializer, ApplySerializer, ApplicationSerializer, ReviewSerializer
from notice.models import Notice
from utils.utility import FormatResponse


# Create your views here.

class AdminViewSet(viewsets.ViewSet):
    permission_classes = [IsSuperUser]

    # /permission/admin/update/
    @action(methods=['post'], detail=False)
    def update(self, request):
        serializer = UserPkSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        serializer = AdminUpdateSerializer(instance=user, data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()

        return FormatResponse()


class MusicianViewSet(viewsets.ViewSet):
    permission_classes = [IsAdminUser]

    # /permission/musician/apply/
    @action(methods=['post'], detail=False, permission_classes=[IsAuthenticated])
    def apply(self, request):
        if request.user.is_musician:
            raise PermissionDenied('已经是乐手的用户无法重复申请')

        serializer = ApplySerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        serializer.save(user=request.user)

        return FormatResponse()

    # /permission/musician/list/
    @action(methods=['post'], detail=False)
    def list(self, request):
        applications = Application.objects.all()
        serializer = ApplicationSerializer(instance=applications, many=True, context={'request': request})

        return FormatResponse(data={
            'applications': serializer.data,
        })

    # /permission/musician/review/
    @action(methods=['post'], detail=False)
    def review(self, request):
        serializer = ReviewSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        application = serializer.validated_data['application']
        agree = serializer.validated_data['agree']

        if application.status != '待审核':
            raise PermissionDenied('已经审核的申请无法重复审核')

        application.status = '已通过' if agree else '已驳回'
        application.save()
        user = application.user
        if agree:
            user.is_musician = True
            user.save()
            notice = Notice.objects.create(
                content='您的乐手申请已通过',
                category='审核通知'
            )
            notice.users.set([user])
        else:
            notice = Notice.objects.create(
                content='您的乐手申请未通过',
                category='审核通知'
            )
            notice.users.set([user])

        return FormatResponse()
