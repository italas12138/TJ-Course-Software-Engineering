from rest_framework import serializers
from rest_framework.exceptions import PermissionDenied

from account.models import UserProfile
from .models import Application
from utils.models import UploadFile


class AdminUpdateSerializer(serializers.ModelSerializer):
    class Meta:
        model = UserProfile
        fields = ['is_staff']


class ApplySerializer(serializers.ModelSerializer):
    video_file_id = serializers.PrimaryKeyRelatedField(source='video_file', queryset=UploadFile.objects.all())

    class Meta:
        model = Application
        fields = ['video_file_id']

    def validate_video_file_id(self, value):
        user = self.context['request'].user
        if value.user != user:
            raise PermissionDenied('无法将不是自己上传的文件作为申请视频')
        return value


class ApplicationSerializer(serializers.ModelSerializer):
    user_id = serializers.PrimaryKeyRelatedField(source='user', read_only=True)
    video_url = serializers.FileField(source='video_file.file', read_only=True)

    class Meta:
        model = Application
        fields = ['id', 'user_id', 'video_url', 'status']


class ReviewSerializer(serializers.Serializer):
    application_id = serializers.PrimaryKeyRelatedField(source='application', queryset=Application.objects.all())
    agree = serializers.BooleanField()
