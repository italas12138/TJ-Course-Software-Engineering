from django.urls import path, include
from permission.views import AdminViewSet, MusicianViewSet
from utils.utility import ActionRouter

router = ActionRouter()
router.register(r'admin', AdminViewSet, basename='admin')
router.register(r'musician', MusicianViewSet, basename='musician')

urlpatterns = [
    path('', include(router.urls))
]
