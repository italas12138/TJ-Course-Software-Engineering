from django.db import models

from account.models import UserProfile
from utils.models import UploadFile


# Create your models here.
class Application(models.Model):
    user = models.ForeignKey(UserProfile, on_delete=models.CASCADE, related_name='applications')
    video_file = models.OneToOneField(UploadFile, on_delete=models.CASCADE, default=None)
    status = models.CharField(max_length=50, choices=(
        ('待审核', '待审核'),
        ('已通过', '已驳回'),
        ('已驳回', '已驳回')
    ), default='待审核')
