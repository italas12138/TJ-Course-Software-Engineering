from django.urls import path, include
from activity.views import ActivityViewSet
from utils.utility import ActionRouter

router = ActionRouter()
router.register(r'', ActivityViewSet, basename='activity')

urlpatterns = [
    path('', include(router.urls))
]
