from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated, IsAdminUser

from activity.models import Activity
from activity.serializers import (ActivityListSerializer, ActivityPkSerializer, ActivityDetailSerializer)
from notice.models import Notice
from utils.utility import FormatResponse


# Create your views here.

class ActivityViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]

    # /activity/list/
    @action(methods=['post'], detail=False)
    def list(self, request):
        serializer = ActivityListSerializer(instance=Activity.objects.all(), many=True)
        return FormatResponse(data={
            'activities': serializer.data
        })

    # /activity/query/
    @action(methods=['post'], detail=False)
    def query(self, request):
        serializer = ActivityPkSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        activity = serializer.validated_data['activity']
        activity_serializer = ActivityDetailSerializer(instance=activity)
        return FormatResponse(data=activity_serializer.data)

    # /activity/create/
    @action(methods=['post'], detail=False, permission_classes=[IsAdminUser])
    def create(self, request):
        serializer = ActivityDetailSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        activity = serializer.save()
        # 发布活动通知
        Notice.objects.create(content='新建活动消息：\n'
                                      f'活动标题:  {activity.title}\n'
                                      f'活动描述:  {activity.description}\n',
                              category='活动通知')
        return FormatResponse(data=serializer.data)

    # /activity/update/
    @action(methods=['post'], detail=False, permission_classes=[IsAdminUser])
    def update(self, request):
        serializer = ActivityPkSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        activity = serializer.validated_data['activity']
        update_serializer = ActivityDetailSerializer(instance=activity, data=request.data, partial=True)
        update_serializer.is_valid(raise_exception=True)
        activity = update_serializer.save()
        # 发布活动
        Notice.objects.create(content='修改活动消息：\n'
                                      f'活动标题:  {activity.title}\n'
                                      f'活动描述:  {activity.description}\n',
                              category='活动通知')
        return FormatResponse(data=update_serializer.data)

    # /activity/delete/
    @action(methods=['post'], detail=False, permission_classes=[IsAdminUser])
    def delete(self, request):
        serializer = ActivityPkSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        activity = serializer.validated_data['activity']
        # 发布活动
        Notice.objects.create(content=f'活动标题:  {activity.title}\n'
                                      f'活动描述:  {activity.description}\n'
                                      '状态:      已被删除\n',
                              category='活动通知')
        activity.delete()
        return FormatResponse()
