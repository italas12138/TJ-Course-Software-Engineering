from rest_framework import serializers

from activity.models import Activity
from utils.utility import primary_key_serializer


class ActivityListSerializer(serializers.ModelSerializer):
    class Meta:
        model = Activity
        exclude = ['description', 'participated_users']


ActivityPkSerializer = primary_key_serializer('activity_id', 'activity', Activity)


class ActivityDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Activity
        exclude = ['participated_users']


class ActivitySaveSerializer(serializers.ModelSerializer):
    class Meta:
        model = Activity
        exclude = ['participated_users']
