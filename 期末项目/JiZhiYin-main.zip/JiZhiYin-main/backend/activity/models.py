from django.db import models

from account.models import UserProfile


# Create your models here.
class Activity(models.Model):
    title = models.CharField(max_length=120)
    description = models.TextField()
    create_at = models.DateTimeField(auto_now_add=True)
    end_at = models.DateTimeField()
    participated_users = models.ManyToManyField(UserProfile, related_name='activities')
