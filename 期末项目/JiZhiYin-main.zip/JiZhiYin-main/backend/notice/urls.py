from django.urls import path, include
from notice.views import NoticeViewSet
from utils.utility import ActionRouter

router = ActionRouter()
router.register(r'', NoticeViewSet, basename='notice')

urlpatterns = [
    path('', include(router.urls))
]
