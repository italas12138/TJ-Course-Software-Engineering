from rest_framework import serializers
from utils.utility import primary_key_serializer

from notice.models import Notice


class NormalDetailSerializer(serializers.ModelSerializer):
    blog_id = serializers.PrimaryKeyRelatedField(source='blog', read_only=True, allow_null=True)

    class Meta:
        model = Notice
        fields = ['id', 'content', 'category', 'timestamp', 'blog_id']


class GlobalCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notice
        fields = ['content', 'category']


class GlobalDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notice
        fields = ['id', 'content', 'category', 'timestamp']
