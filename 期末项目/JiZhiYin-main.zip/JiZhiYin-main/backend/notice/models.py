from django.db import models

from account.models import UserProfile
from blog.models import Blog


# Create your models here.
class Notice(models.Model):
    content = models.TextField()
    # TODO choices
    category = models.CharField(max_length=50, choices=(
        ('全局通知', '全局通知'),
        ('活动通知', '活动通知'),
        ('好友消息', '好友消息'),
        ('审核通知', '审核通知'),
        ('系统推荐', '系统推荐')
    ))
    timestamp = models.DateTimeField(auto_now_add=True)
    blog = models.ForeignKey(Blog, on_delete=models.SET_NULL, related_name='noticed_blogs', null=True)
    users = models.ManyToManyField(UserProfile, related_name='received_notices')
