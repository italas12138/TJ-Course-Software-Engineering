from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated, IsAdminUser
from django.db.models import Q

from notice.models import Notice

from notice.serializers import NormalDetailSerializer, GlobalCreateSerializer, GlobalDetailSerializer

from utils.utility import FormatResponse


# Create your views here.

class NoticeViewSet(viewsets.ViewSet):
    permission_classes = [IsAdminUser]

    # /notice/list_normal/
    @action(methods=['post'], detail=False, permission_classes=[IsAuthenticated])
    def list_normal(self, request):
        global_notices = Notice.objects.filter(Q(category='全局通知') | Q(category='活动通知'))
        notices = global_notices.union(
            request.user.received_notices.all())
        serializer = NormalDetailSerializer(instance=notices, many=True)
        return FormatResponse(data={
            'notices': serializer.data
        })

    # /notice/list_global/
    @action(methods=['post'], detail=False)
    def list_global(self, request):
        serializer = NormalDetailSerializer(instance=Notice.objects.filter(category='全局通知'), many=True)
        return FormatResponse(data={
            'notices': serializer.data
        })

    # /notice/create/
    @action(methods=['post'], detail=False)
    def create(self, request):
        serializer = GlobalCreateSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        notice = serializer.save()
        notice_serializer = GlobalDetailSerializer(instance=notice)
        return FormatResponse(data=notice_serializer.data)
