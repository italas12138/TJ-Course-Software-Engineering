from django.urls import path, include
from interact.views import ChatViewSet, InvitationViewSet
from utils.utility import ActionRouter

router = ActionRouter()
router.register(r'chat', ChatViewSet, basename='chat')
router.register(r'invitation', InvitationViewSet, basename='invitation')

urlpatterns = [
    path('', include(router.urls))
]
