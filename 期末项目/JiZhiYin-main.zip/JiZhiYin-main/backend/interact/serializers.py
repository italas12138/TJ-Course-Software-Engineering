from rest_framework import serializers
from rest_framework.exceptions import PermissionDenied

from account.models import UserProfile, UserGroup
from blog.models import Blog
from interact.models import Chat, Invitation


class FriendSerializer(serializers.ModelSerializer):
    user_id = serializers.PrimaryKeyRelatedField(source='friend', queryset=UserProfile.objects.all())

    class Meta:
        model = UserProfile
        fields = ['user_id']

    def validate_user_id(self, value):
        user = self.context['request'].user
        if not user.friends.filter(pk=value.pk).exists():
            raise PermissionDenied('Ta不是你的好友')
        return value


class GroupSerializer(serializers.ModelSerializer):
    group_id = serializers.PrimaryKeyRelatedField(source='group', queryset=UserGroup.objects.all())

    class Meta:
        model = UserGroup
        fields = ['group_id']

    def validate_group_id(self, value):
        user = self.context['request'].user
        if not user.groups.filter(pk=value.pk).exists():
            raise PermissionDenied('用户未加入当前组')
        return value


class UserChatSerializer(serializers.ModelSerializer):
    image_url = serializers.FileField(source='image_file.file', read_only=True, allow_null=True)

    class Meta:
        model = UserProfile
        fields = ['id', 'nickname', 'image_url']


class UserMusicianSerializer(serializers.ModelSerializer):
    image_url = serializers.FileField(source='image_file.file', read_only=True, allow_null=True)

    class Meta:
        model = UserProfile
        fields = ['id', 'nickname', 'image_url', 'is_musician']


class GroupNestedSerializer(serializers.ModelSerializer):
    image_url = serializers.FileField(source='image_file.file', read_only=True, allow_null=True)

    class Meta:
        model = UserGroup
        fields = ['id', 'name', 'image_url']


class ChatSerializer(serializers.ModelSerializer):
    from_user = UserMusicianSerializer(read_only=True)
    blog_id = serializers.PrimaryKeyRelatedField(source='blog', read_only=True)

    class Meta:
        model = Chat
        fields = ['from_user', 'content', 'blog_id', 'timestamp']


class SendFriendSerializer(serializers.ModelSerializer):
    user_id = serializers.PrimaryKeyRelatedField(source='to_user', queryset=UserProfile.objects.all())
    blog_id = serializers.PrimaryKeyRelatedField(source='blog', queryset=Blog.objects.all(), allow_null=True)

    class Meta:
        model = Chat
        fields = ['user_id', 'content', 'blog_id']

    def validate_user_id(self, value):
        user = self.context['request'].user
        if not user.friends.filter(pk=value.pk).exists():
            raise PermissionDenied('Ta不是你的好友')
        return value


class SendFriendChatSerializer(serializers.ModelSerializer):
    to_user_id = serializers.PrimaryKeyRelatedField(source='to_user', read_only=True)

    class Meta:
        model = Chat
        fields = ['to_user_id', 'content', 'timestamp']


class SendGroupSerializer(serializers.ModelSerializer):
    group_id = serializers.PrimaryKeyRelatedField(source='to_group', queryset=UserGroup.objects.all())
    blog_id = serializers.PrimaryKeyRelatedField(source='blog', queryset=Blog.objects.all(), allow_null=True)

    class Meta:
        model = Chat
        fields = ['group_id', 'content', 'blog_id']

    def validate_group_id(self, value):
        user = self.context['request'].user
        if not user.groups.filter(pk=value.pk).exists():
            raise PermissionDenied('无法向未加入的群组发送消息')
        return value


class SendGroupChatSerializer(serializers.ModelSerializer):
    to_group_id = serializers.PrimaryKeyRelatedField(source='to_group', read_only=True)

    class Meta:
        model = Chat
        fields = ['to_group_id', 'content', 'timestamp']


class InviteFriendSerializer(serializers.ModelSerializer):
    user_id = serializers.PrimaryKeyRelatedField(source='to_user', queryset=UserProfile.objects.all())

    class Meta:
        model = Invitation
        fields = ['user_id']

    def validate_user_id(self, value):
        user = self.context['request'].user
        if user.friends.filter(pk=value.pk).exists():
            raise PermissionDenied('Ta已经是你的好友')
        if Invitation.objects.filter(to_user=value, from_user=user, status='待处理').exists():
            raise PermissionDenied('已经邀请过Ta')
        return value


class InviteGroupSerializer(serializers.ModelSerializer):
    user_id = serializers.PrimaryKeyRelatedField(source='to_user', queryset=UserProfile.objects.all())
    group_id = serializers.PrimaryKeyRelatedField(source='dst_group', queryset=UserGroup.objects.all())

    class Meta:
        model = Invitation
        fields = ['user_id', 'group_id']

    def validate_user_id(self, value):
        user = self.context['request'].user
        if not user.friends.filter(pk=value.pk).exists():
            raise PermissionDenied('Ta不是你的好友')
        return value

    def validate_group_id(self, value):
        user = self.context['request'].user
        if not user.groups.filter(pk=value.pk).exists():
            raise PermissionDenied('无法在未加入的群组中邀请好友')
        return value

    def validate(self, attrs):
        user = self.context['request'].user
        to_user = attrs.get('to_user')
        dst_group = attrs.get('dst_group')
        if to_user.groups.filter(pk=dst_group.pk).exists():
            raise PermissionDenied('Ta已经在群组中')
        if Invitation.objects.filter(to_user=to_user, dst_group=dst_group, status='待处理').exists():
            raise PermissionDenied('Ta已经被邀请过')
        return attrs


class InvitationSerializer(serializers.ModelSerializer):
    from_user = UserChatSerializer()
    dst_group = GroupNestedSerializer()

    class Meta:
        model = Invitation
        fields = ['id', 'from_user', 'dst_group', 'status']


class ReplyInvitationSerializer(serializers.ModelSerializer):
    invitation_id = serializers.PrimaryKeyRelatedField(source='invitation', queryset=Invitation.objects.all())
    agree = serializers.BooleanField()

    class Meta:
        model = Invitation
        fields = ['invitation_id', 'agree']

    def validate_invitation_id(self, value):
        user = self.context['request'].user
        if value.to_user != user:
            raise PermissionDenied('无法回复不是向自己发出的邀请')
        return value
