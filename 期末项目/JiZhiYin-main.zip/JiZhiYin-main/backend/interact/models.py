from django.db import models

from account.models import UserProfile, UserGroup
from blog.models import Blog


# Create your models here.
class Chat(models.Model):
    content = models.TextField()
    blog = models.ForeignKey(Blog, on_delete=models.SET_NULL, null=True)
    timestamp = models.DateTimeField(auto_now_add=True)
    from_user = models.ForeignKey(UserProfile, on_delete=models.CASCADE,
                                  related_name='sent_chats')
    to_group = models.ForeignKey(UserGroup, on_delete=models.SET_NULL,
                                 related_name='received_chats', null=True)
    to_user = models.ForeignKey(UserProfile, on_delete=models.SET_NULL,
                                related_name='received_chats', null=True)


class Invitation(models.Model):
    from_user = models.ForeignKey(UserProfile, on_delete=models.CASCADE,
                                  related_name='sent_invitations')
    to_user = models.ForeignKey(UserProfile, on_delete=models.SET_NULL,
                                related_name='received_invitations', null=True)
    dst_group = models.ForeignKey(UserGroup, on_delete=models.SET_NULL,
                                  related_name='received_invitations', null=True)
    status = models.CharField(max_length=50, choices=(
        ('待处理', '待处理'),
        ('已同意', '已同意'),
        ('已拒绝', '已拒绝')
    ), default='待处理')
