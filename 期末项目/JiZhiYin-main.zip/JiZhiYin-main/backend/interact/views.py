from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import PermissionDenied
from rest_framework.permissions import IsAuthenticated
from django.db.models import Q

from interact.serializers import (FriendSerializer, ChatSerializer, GroupSerializer, SendFriendSerializer,
                                  SendFriendChatSerializer, SendGroupSerializer, SendGroupChatSerializer,
                                  InviteFriendSerializer, InviteGroupSerializer, InvitationSerializer,
                                  ReplyInvitationSerializer)
from interact.models import Chat, Invitation
from notice.models import Notice
from relation.models import Unread
from utils.utility import FormatResponse


# Create your views here.

class ChatViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]

    # /interact/chat/list_friend/
    @action(methods=['post'], detail=False)
    def list_friend(self, request):
        serializer = FriendSerializer(instance=request.user, data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        user = request.user
        friend = serializer.validated_data['friend']
        chats = Chat.objects.filter(
            Q(from_user=user, to_user=friend) |
            Q(from_user=friend, to_user=user)
        )
        unread = Unread.objects.get(from_user=friend, to_user=user)
        unread.count = 0
        unread.save()
        chat_serializer = ChatSerializer(instance=chats, many=True, context={'request': request})
        return FormatResponse(data={
            'chats': chat_serializer.data,
        })

    # /interact/chat/list_group/
    @action(methods=['post'], detail=False)
    def list_group(self, request):
        user = request.user
        serializer = GroupSerializer(instance=user, data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        group = serializer.validated_data['group']
        chats = Chat.objects.filter(to_group=group)
        unread = Unread.objects.get(from_group=group, to_user=user)
        unread.count = 0
        unread.save()
        chat_serializer = ChatSerializer(instance=chats, many=True, context={'request': request})
        return FormatResponse(data={
            'chats': chat_serializer.data,
        })

    # /interact/chat/send_friend/
    @action(methods=['post'], detail=False)
    def send_friend(self, request):
        serializer = SendFriendSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        chat = serializer.save(from_user=request.user)
        # 更新 Unread
        unread = Unread.objects.get(to_user=serializer.validated_data['to_user'], from_user=request.user)
        unread.count += 1
        unread.save()
        send_serializer = SendFriendChatSerializer(instance=chat)
        return FormatResponse(data=send_serializer.data)

    # /interact/chat/send_group/
    @action(methods=['post'], detail=False)
    def send_group(self, request):
        serializer = SendGroupSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        chat = serializer.save(from_user=request.user)
        # 更新 Unread
        from_group = serializer.validated_data['to_group']
        for to_user in from_group.members.all():
            if to_user != request.user:
                unread = Unread.objects.get(to_user=to_user,
                                            from_group=from_group)
                unread.count += 1
                unread.save()
        send_serializer = SendGroupChatSerializer(instance=chat)
        return FormatResponse(data=send_serializer.data)


class InvitationViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]

    # /interact/invitation/invite_friend/
    @action(methods=['post'], detail=False)
    def invite_friend(self, request):
        serializer = InviteFriendSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        serializer.save(from_user=request.user)
        return FormatResponse()

    # /interact/invitation/invite_group/
    @action(methods=['post'], detail=False)
    def invite_group(self, request):
        serializer = InviteGroupSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        serializer.save(from_user=request.user)
        return FormatResponse()

    # /interact/invitation/list/
    @action(methods=['post'], detail=False)
    def list(self, request):
        user = request.user
        invitations = Invitation.objects.filter(to_user=user)
        invite_serializer = InvitationSerializer(instance=invitations, many=True, context={'request': request})
        return FormatResponse(data={
            'invitations': invite_serializer.data
        })

    # /interact/invitation/reply/
    @action(methods=['post'], detail=False)
    def reply(self, request):
        user = request.user
        serializer = ReplyInvitationSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        invitation = serializer.validated_data['invitation']
        agree = serializer.validated_data['agree']

        if invitation.status != '待处理':
            raise PermissionDenied('已经处理的邀请无法重复处理')

        invitation.status = '已同意' if agree else '已拒绝'
        invitation.save()
        from_user = invitation.from_user
        if agree:
            if invitation.dst_group is None:
                # 同意好友请求
                user.friends.add(from_user)
                # 新建双方 Unread
                obj, _ = Unread.objects.get_or_create(to_user=user, from_user=from_user)
                obj.count = 0
                obj.save()
                obj, _ = Unread.objects.get_or_create(to_user=from_user, from_user=user)
                obj.count = 0
                obj.save()
                # from_user.friends.add(user)
                notice = Notice.objects.create(
                    content=f'{user.nickname}同意了您的好友申请',
                    category='好友消息'
                )
                notice.users.set([from_user])
            else:
                # 同意组请求
                invitation.dst_group.count += 1
                invitation.dst_group.save()
                user.groups.add(invitation.dst_group)
                # 新建组员与 group 的 Unread
                obj, _ = Unread.objects.get_or_create(to_user=user, from_group=invitation.dst_group)
                obj.count = 0
                obj.save()
                notice = Notice.objects.create(
                    content=f'{user.nickname}同意了您的入群邀请',
                    category='好友消息'
                )
                notice.users.set([from_user])
        else:
            if invitation.dst_group is None:
                notice = Notice.objects.create(
                    content=f'{user.nickname}拒绝了您的好友申请',
                    category='好友消息'
                )
                notice.users.set([from_user])
            else:
                notice = Notice.objects.create(
                    content=f'{user.nickname}拒绝了您的入群邀请',
                    category='好友消息'
                )
                notice.users.set([from_user])

        return FormatResponse()
