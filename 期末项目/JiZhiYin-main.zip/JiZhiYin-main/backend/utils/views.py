from django.db.models import Q
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated

from account.models import UserProfile
from account.serializers import UserOtherSerializer
from blog.models import Blog
from blog.serializers import NormalSerializer
from utils.models import Tag
from utils.serializers import UploadFileSerializer, FileInfoSerializer, SearchSerializer, TagSerializer
from utils.utility import FormatResponse


# Create your views here.

class UtilsViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]

    # /utils/upload/
    @action(methods=['post'], detail=False)
    def upload(self, request):
        serializer = UploadFileSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        info = serializer.save(user=request.user)
        info_serializer = FileInfoSerializer(instance=info, context={'request': request})
        return FormatResponse(data=info_serializer.data)

    # /utils/search/
    @action(methods=['post'], detail=False)
    def search(self, request):
        serializer = SearchSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        keyword = serializer.validated_data['keyword']
        tags = serializer.validated_data['tags']

        users = UserProfile.objects.filter(
            Q(nickname__icontains=keyword) | Q(description__icontains=keyword))
        blogs = Blog.objects.filter(
            Q(title__icontains=keyword) | Q(content__icontains=keyword))
        query = Q()
        if tags:
            for tag in tags:
                query |= Q(tags=tag)
            blogs = blogs.filter(query)

        user_serializer = UserOtherSerializer(instance=users, many=True, context={'request': request})
        blog_serializer = NormalSerializer(instance=blogs, many=True, context={'request': request})
        return FormatResponse(data={
            'users': user_serializer.data,
            'blogs': blog_serializer.data
        })

    # /utils/list_tag/
    @action(methods=['post'], detail=False)
    def list_tag(self, request):
        serializer = TagSerializer(instance=Tag.objects.all(), many=True)
        return FormatResponse(data=serializer.data)
