from rest_framework.routers import SimpleRouter, DynamicRoute
from rest_framework.response import Response
from rest_framework.status import HTTP_200_OK
from rest_framework.exceptions import APIException
from rest_framework.views import exception_handler
from rest_framework import serializers


class ActionRouter(SimpleRouter):
    routes = [
        DynamicRoute(
            url=r'^{prefix}/{url_path}{trailing_slash}$',
            name='{basename}-{url_name}',
            detail=False,
            initkwargs={}
        )
    ]


class FormatResponse(Response):

    def __init__(self, data=None, code=HTTP_200_OK, msg='', *args, **kwargs):
        if data is None:
            data = {}
        super(FormatResponse, self).__init__(data={
            'code': code,
            'msg': msg,
            'data': data
        }, *args, **kwargs)


# Create your views here.
def general_exception_handler(exc, context):
    # Call REST framework's default exception handler first,
    # to get the standard error response.
    response = exception_handler(exc, context)

    if response is not None:
        if isinstance(exc, APIException):
            if isinstance(exc.detail, (list, dict)):
                data = {'detail': exc.detail}
                msg = exc.default_code
            else:
                data = None
                msg = exc.detail
        else:
            data = response.data
            msg = ''
        return FormatResponse(data=data, code=response.status_code, msg=msg)

    return response


def primary_key_serializer(field_name, source, model):
    class PkSerializer(serializers.Serializer):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.fields[field_name] = serializers.PrimaryKeyRelatedField(queryset=model.objects.all(), source=source)

    return PkSerializer
