from django.db import models

from account.models import UserProfile

# Create your models here.

path_map = {
    '图像': 'image',
    '音乐': 'music',
    '视频': 'video',
    '个人头像': 'UserAvatar',
    '群组头像': 'GroupAvatar',
    '博客图像': 'BlogImage',
    '博客音乐': 'BlogMusic',
    '作品音乐': 'WorkMusic',
    '博客视频': 'BlogVideo',
    '申请视频': 'ApplyVideo'
}


def upload_to_path(instance, filename):
    category = instance.category
    usage = instance.usage
    return f'{instance.user.username}/{path_map[category]}/{path_map[usage]}/{filename}'


class UploadFile(models.Model):
    file = models.FileField(upload_to=upload_to_path)
    create_at = models.DateTimeField(auto_now_add=True)
    # TODO choices
    category = models.CharField(max_length=50, choices=(
        ('图像', '图像'),
        ('音乐', '音乐'),
        ('视频', '视频'),
    ))
    usage = models.CharField(max_length=50, choices=(
        ('个人头像', '个人头像'),
        ('群组头像', '群组头像'),
        ('博客图像', '博客图像'),
        ('博客音乐', '博客音乐'),
        ('作品音乐', '作品音乐'),
        ('博客视频', '博客视频'),
        ('申请视频', '申请视频'),
    ))
    user = models.ForeignKey(UserProfile, on_delete=models.SET_NULL,
                             null=True, related_name='files')


class Tag(models.Model):
    name = models.CharField(max_length=50, unique=True)
