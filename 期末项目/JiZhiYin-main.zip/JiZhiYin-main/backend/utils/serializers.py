from rest_framework import serializers

from utils.models import UploadFile, Tag


class UploadFileSerializer(serializers.ModelSerializer):
    class Meta:
        model = UploadFile
        fields = '__all__'


class FileInfoSerializer(serializers.ModelSerializer):
    url = serializers.FileField(source='file')

    class Meta:
        model = UploadFile
        fields = ['id', 'url']


class SearchSerializer(serializers.Serializer):
    keyword = serializers.CharField()
    tags = serializers.SlugRelatedField(many=True, queryset=Tag.objects.all(), slug_field='name', allow_empty=True)


class TagSerializer(serializers.ModelSerializer):
    class Meta:
        model = Tag
        fields = ['name']
