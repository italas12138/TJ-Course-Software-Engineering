from django.urls import path, include
from utils.views import UtilsViewSet
from utils.utility import ActionRouter

router = ActionRouter()
router.register(r'', UtilsViewSet, basename='utils')

urlpatterns = [
    path('', include(router.urls))
]
