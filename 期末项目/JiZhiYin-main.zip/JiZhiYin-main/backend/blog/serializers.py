from rest_framework import serializers
from rest_framework.exceptions import PermissionDenied

from account.models import UserProfile
from account.serializers import MedalSerializer
from activity.models import Activity
from blog.models import Blog
from utils.models import UploadFile, Tag
from utils.utility import primary_key_serializer


class IsLikedMixin(serializers.Serializer):
    is_liked = serializers.SerializerMethodField()

    def get_is_liked(self, obj):
        user = self.context['request'].user
        return user in obj.liked_users.all()


class IsCollectedMixin(serializers.Serializer):
    is_collected = serializers.SerializerMethodField()

    def get_is_collected(self, obj):
        user = self.context['request'].user
        return user in obj.collected_users.all()


class VideoFileMixin(serializers.Serializer):
    video_file_id = serializers.PrimaryKeyRelatedField(source='video_file', allow_null=True,
                                                       queryset=UploadFile.objects.all())

    def validate_video_file_id(self, value):
        user = self.context['request'].user
        if value is not None and value.user != user:
            raise PermissionDenied('无法使用其他用户上传的视频')
        return value


class MusicFileMixin(serializers.Serializer):
    music_file_id = serializers.PrimaryKeyRelatedField(source='music_file', allow_null=True,
                                                       queryset=UploadFile.objects.all())

    def validate_music_file_id(self, value):
        user = self.context['request'].user
        if value is not None and value.user != user:
            raise PermissionDenied('无法使用其他用户上传的音乐')
        return value


class MusicFileNotNullMixin(serializers.Serializer):
    music_file_id = serializers.PrimaryKeyRelatedField(source='music_file', queryset=UploadFile.objects.all())

    def validate_music_file_id(self, value):
        user = self.context['request'].user
        if value.user != user:
            raise PermissionDenied('无法使用其他用户上传的音乐')
        return value


class NestedUserSerializer(serializers.ModelSerializer):
    image_url = serializers.FileField(source='image_file.file', read_only=True, allow_null=True)

    class Meta:
        model = UserProfile
        fields = ['id', 'nickname', 'image_url']


class NormalSerializer(IsLikedMixin, IsCollectedMixin, serializers.ModelSerializer):
    author = NestedUserSerializer(read_only=True)
    tags = serializers.SlugRelatedField(slug_field='name', read_only=True, many=True)

    class Meta:
        model = Blog
        fields = ['id', 'author', 'title', 'content', 'timestamp', 'tags',
                  'is_liked', 'like_count', 'is_collected', 'collect_count', 'comment_count']


class NormalCreateSerializer(serializers.ModelSerializer, VideoFileMixin, MusicFileMixin):
    tags = serializers.SlugRelatedField(many=True, queryset=Tag.objects.all(), slug_field='name')

    class Meta:
        model = Blog
        fields = ['title', 'content', 'video_file_id', 'music_file_id', 'tags', 'is_only_for_musician']


ActivityPkSerializer = primary_key_serializer('activity_id', 'activity', Activity)


class WorkSerializer(serializers.ModelSerializer, IsLikedMixin, IsCollectedMixin):
    author = NestedUserSerializer(read_only=True)
    music_url = serializers.FileField(source='music_file.file')

    class Meta:
        model = Blog
        fields = ['id', 'author', 'title', 'content', 'music_url', 'timestamp', 'is_liked', 'like_count',
                  'is_collected', 'collect_count', 'comment_count']


class WorkCreateSerializer(serializers.ModelSerializer, MusicFileNotNullMixin):
    activity_id = serializers.PrimaryKeyRelatedField(source='activity', queryset=Activity.objects.all())

    class Meta:
        model = Blog
        fields = ['title', 'content', 'music_file_id', 'activity_id']


BlogPkSerializer = primary_key_serializer('blog_id', 'blog', Blog)


class UserMedalSerializer(serializers.ModelSerializer):
    image_url = serializers.FileField(source='image_file.file', read_only=True, allow_null=True)
    medal_group = MedalSerializer(read_only=True)

    class Meta:
        model = UserProfile
        fields = ['id', 'nickname', 'image_url', 'medal_group']


class DetailSerializer(serializers.ModelSerializer, IsLikedMixin, IsCollectedMixin):
    author = UserMedalSerializer(read_only=True)
    video_url = serializers.FileField(source='video_file.file', read_only=True, allow_null=True)
    music_url = serializers.FileField(source='music_file.file', read_only=True, allow_null=True)
    tags = serializers.SlugRelatedField(slug_field='name', read_only=True, many=True)

    class Meta:
        model = Blog
        fields = ['id', 'author', 'title', 'content', 'video_url', 'music_url', 'timestamp', 'tags',
                  'is_liked', 'like_count', 'is_collected', 'collect_count', 'comment_count']


class UpdateSerializer(serializers.ModelSerializer, VideoFileMixin, MusicFileMixin):
    tags = serializers.SlugRelatedField(many=True, queryset=Tag.objects.all(), slug_field='name')

    class Meta:
        model = Blog
        fields = ['title', 'content', 'video_file_id', 'music_file_id', 'tags', 'is_only_for_musician']


class SetLikeSerializer(serializers.Serializer):
    blog_id = serializers.PrimaryKeyRelatedField(source='blog', queryset=Blog.objects.all())
    is_liked = serializers.BooleanField()


class ShowLikeSerializer(serializers.ModelSerializer, IsLikedMixin):
    class Meta:
        model = Blog
        fields = ['is_liked', 'like_count']


class SetCollectSerializer(serializers.Serializer):
    blog_id = serializers.PrimaryKeyRelatedField(source='blog', queryset=Blog.objects.all())
    is_collected = serializers.BooleanField()


class ShowCollectSerializer(serializers.ModelSerializer, IsCollectedMixin):
    class Meta:
        model = Blog
        fields = ['is_collected', 'collect_count']
