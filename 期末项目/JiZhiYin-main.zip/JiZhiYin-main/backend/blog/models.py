from django.db import models

from account.models import UserProfile
from activity.models import Activity
from utils.models import UploadFile, Tag


# Create your models here.
class Blog(models.Model):
    title = models.CharField(max_length=255)
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)
    tags = models.ManyToManyField(Tag, related_name='contained_blogs')
    liked_users = models.ManyToManyField(UserProfile, related_name='like_blogs')
    like_count = models.IntegerField(default=0)
    collected_users = models.ManyToManyField(UserProfile, related_name='collect_blogs')
    collect_count = models.IntegerField(default=0)
    comment_count = models.IntegerField(default=0)
    activity = models.ForeignKey(Activity, on_delete=models.SET_NULL, null=True, blank=True)
    is_only_for_musician = models.BooleanField(default=False)
    video_file = models.OneToOneField(UploadFile, on_delete=models.SET_NULL, null=True, blank=True,
                                      related_name='video_used_blog')
    music_file = models.OneToOneField(UploadFile, on_delete=models.SET_NULL, null=True, blank=True,
                                      related_name='music_used_blog')
    author = models.ForeignKey(UserProfile, on_delete=models.SET_NULL, null=True, blank=True)
