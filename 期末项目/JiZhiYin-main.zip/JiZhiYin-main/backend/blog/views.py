from django.db.models import Count, Q
from django.utils import timezone
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import PermissionDenied
from rest_framework.permissions import IsAuthenticated

from account.models import UserProfile
from blog.models import Blog
from blog.serializers import NormalSerializer, NormalCreateSerializer, ActivityPkSerializer, WorkSerializer, \
    WorkCreateSerializer, BlogPkSerializer, DetailSerializer, UpdateSerializer, SetLikeSerializer, ShowLikeSerializer, \
    SetCollectSerializer, ShowCollectSerializer
from notice.models import Notice
from utils.utility import FormatResponse


# Create your views here.

class BlogNormalViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]

    # /blog/normal/list/
    @action(methods=['post'], detail=False)
    def list(self, request):
        serializer = NormalSerializer(instance=Blog.objects.all(), many=True, context={'request': request})
        return FormatResponse(data={
            'blogs': serializer.data
        })

    # /blog/normal/create/
    @action(methods=['post'], detail=False)
    def create(self, request):
        serializer = NormalCreateSerializer(data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        blog = serializer.save(author=request.user)
        normal_serializer = DetailSerializer(instance=blog, context={'request': request})
        return FormatResponse(data=normal_serializer.data)


class BlogWorkViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]

    # /blog/work/list/
    @action(methods=['post'], detail=False)
    def list(self, request):
        serializer = ActivityPkSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        activity = serializer.validated_data['activity']
        work_serializer = WorkSerializer(instance=Blog.objects.filter(activity=activity), many=True,
                                         context={'request': request})
        return FormatResponse(data={
            'blogs': work_serializer.data
        })

    # /blog/work/create/
    @action(methods=['post'], detail=False)
    def create(self, request):
        serializer = WorkCreateSerializer(data=request.data, context={"request": request})
        serializer.is_valid(raise_exception=True)
        activity = serializer.validated_data['activity']

        if activity.end_at < timezone.now():
            raise PermissionDenied('无法在已经结束的活动中上传作品')

        blog = serializer.save(author=request.user)
        # TODO 发布作品成为活动参与者
        activity = serializer.validated_data['activity']
        if not activity.participated_users.filter(pk=request.user.pk).exists():
            activity.participated_users.add(request.user)

        work_serializer = WorkSerializer(instance=blog, context={'request': request})
        return FormatResponse(data=work_serializer.data)


def recommend_blog(blog, msg):
    blog_tags = blog.tags
    tag_count = blog_tags.count()
    users = UserProfile.objects.annotate(
        tag_score=Count('prefer_tags', filter=Q(prefer_tags__in=blog_tags)) / tag_count).order_by(
        '-tag_score')[:100]
    notice = Notice.objects.create(content=f'热门帖子推荐！\n'
                                           f'标题：{blog.title}\n'
                                           f'    {msg}\n',
                                   category='系统推荐', blog=blog)
    notice.users.set(users)


class BlogDetailViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]

    # /blog/detail/query/
    @action(methods=['post'], detail=False)
    def query(self, request):
        serializer = BlogPkSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        blog = serializer.validated_data['blog']
        detail_serializer = DetailSerializer(instance=blog, context={'request': request})
        return FormatResponse(data=detail_serializer.data)

    # /blog/detail/update/
    @action(methods=['post'], detail=False)
    def update(self, request):
        pk_serializer = BlogPkSerializer(data=request.data)
        pk_serializer.is_valid(raise_exception=True)
        blog = pk_serializer.validated_data['blog']

        if blog.author != request.user:
            raise PermissionDenied('无法修改不是自己发布的帖子')

        serializer = UpdateSerializer(instance=blog, data=request.data, partial=True,
                                      context={'request': request})
        serializer.is_valid(raise_exception=True)
        serializer.save()
        blog_serializer = DetailSerializer(instance=blog, context={'request': request})
        return FormatResponse(data=blog_serializer.data)

    # /blog/detail/delete/
    @action(methods=['post'], detail=False)
    def delete(self, request):
        serializer = BlogPkSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        blog = serializer.validated_data['blog']

        if blog.author != request.user:
            raise PermissionDenied('无法删除不是自己发布的帖子')

        blog.delete()
        return FormatResponse()

    # /blog/detail/set_like/
    @action(methods=['post'], detail=False)
    def set_like(self, request):
        serializer = SetLikeSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        blog = serializer.validated_data['blog']
        is_liked = serializer.validated_data['is_liked']

        activity = blog.activity
        if activity is not None and activity.participated_users.filter(pk=request.user.pk).exists():
            raise PermissionDenied('未参与当前活动的用户无法点赞')

        if is_liked and not blog.liked_users.filter(pk=request.user.pk).exists():
            blog.like_count += 1
            blog.liked_users.add(request.user)
            if blog.like_count == 50:
                recommend_blog(blog, '点赞量到达 50')
        elif not is_liked and blog.liked_users.filter(pk=request.user.pk).exists():
            blog.like_count -= 1
            blog.liked_users.remove(request.user)
        blog.save()

        like_serializer = ShowLikeSerializer(instance=blog, context={'request': request})
        return FormatResponse(data=like_serializer.data)

    # /blog/detail/set_collect/
    @action(methods=['post'], detail=False)
    def set_collect(self, request):
        serializer = SetCollectSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        blog = serializer.validated_data['blog']
        is_collected = serializer.validated_data['is_collected']

        activity = blog.activity
        if activity is not None and activity.participated_users.filter(pk=request.user.pk).exists():
            raise PermissionDenied('未参与当前活动的用户无法收藏')

        if is_collected and not blog.collected_users.filter(pk=request.user.pk).exists():
            blog.collect_count += 1
            blog.collected_users.add(request.user)
            if blog.collect_count == 50:
                recommend_blog(blog, '收藏量到达 50')
        elif not is_collected and blog.collected_users.filter(pk=request.user.pk).exists():
            blog.collect_count -= 1
            blog.collected_users.remove(request.user)
        blog.save()

        collect_serializer = ShowCollectSerializer(instance=blog, context={'request': request})
        return FormatResponse(data=collect_serializer.data)
