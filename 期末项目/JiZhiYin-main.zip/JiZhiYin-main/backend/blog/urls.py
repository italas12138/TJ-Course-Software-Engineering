from django.urls import path, include
from blog.views import BlogNormalViewSet, BlogWorkViewSet, BlogDetailViewSet
from utils.utility import ActionRouter

router = ActionRouter()
router.register(r'normal', BlogNormalViewSet, basename='blog-normal')
router.register(r'work', BlogWorkViewSet, basename='blog-work')
router.register(r'detail', BlogDetailViewSet, basename='blog-detail')

urlpatterns = [
    path('', include(router.urls))
]
