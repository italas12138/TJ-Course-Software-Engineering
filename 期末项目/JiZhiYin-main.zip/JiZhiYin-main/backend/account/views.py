import random
from datetime import timedelta

from django.utils import timezone
from django.core.mail import send_mail
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import ValidationError
from rest_framework.permissions import IsAuthenticated
from rest_framework.authtoken.serializers import AuthTokenSerializer
from rest_framework.authtoken.models import Token

from account.models import UserProfile, Verification
from account.serializers import (RegisterSerializer, UserSelfSerializer, UserPkSerializer, UserOtherSerializer,
                                 UserUpdateSerializer, VerifySerializer, PasswordSerializer)

from utils.utility import FormatResponse


# Create your views here.

def check_verification(email, code):
    try:
        verify = Verification.objects.get(email=email)
    except Verification.DoesNotExist:
        raise ValidationError({'email': '该邮箱不存在验证码'})
    if verify.code != code:
        raise ValidationError({'code': '验证码错误'})
    if verify.expiration < timezone.now():
        verify.delete()
        raise ValidationError({'code': '验证码过期'})
    verify.delete()


class AccountViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]

    # /account/login/
    @action(methods=['post'], detail=False, permission_classes=[])
    def login(self, request):
        serializer = AuthTokenSerializer(data=request.data,
                                         context={'request': request})
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        token, _ = Token.objects.get_or_create(user=user)
        return FormatResponse({
            'token': token.key
        })

    # /account/register/
    @action(methods=['post'], detail=False, permission_classes=[])
    def register(self, request):
        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.validated_data['email']
        code = serializer.validated_data['code']
        username = serializer.validated_data['username']
        password = serializer.validated_data['password']
        check_verification(email, code)
        if UserProfile.objects.filter(username=username).exists():
            raise ValidationError({'username': '用户名已存在'})
        if UserProfile.objects.filter(email=email).exists():
            raise ValidationError('邮箱已存在')
        UserProfile.objects.create_user(username=username, email=email, password=password, nickname=f'用户{username}')
        return FormatResponse()

    # /account/me/
    @action(methods=['post'], detail=False)
    def me(self, request):
        serializer = UserSelfSerializer(instance=request.user, context={'request': request})
        return FormatResponse(data=serializer.data)

    # /account/query/
    @action(methods=['post'], detail=False, )
    def query(self, request):
        serializer = UserPkSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        user_serializer = UserSelfSerializer(instance=user, context={'request': request})
        return FormatResponse(data=user_serializer.data)

    # /account/update_info/
    @action(methods=['post'], detail=False)
    def update_info(self, request):
        serializer = UserUpdateSerializer(instance=request.user, data=request.data,
                                          partial=True, context={'request': request})
        serializer.is_valid(raise_exception=True)
        serializer.save()
        user_serializer = UserSelfSerializer(instance=request.user, context={'request': request})
        return FormatResponse(data=user_serializer.data)

    # /account/verify/
    @action(methods=['post'], detail=False, permission_classes=[])
    def verify(self, request):
        serializer = VerifySerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.validated_data['email']
        code = ''.join(random.choices('0123456789', k=6))

        # 邮箱发送验证码
        send_mail(
            subject='欢迎使用我们的网站！请验证您的邮箱',
            message='尊敬的用户，\n'
                    '    感谢您使用我们的网站！为了确保您的账户安全和数据保护，我们需要验证您提供的邮箱。\n'
                    '    请在 5分钟 内输入验证码以验证您的邮箱：\n'
                    f'    验证码：{code}\n'
                    '    请注意，为了确保顺利验证您的邮箱，请不要回复此邮件。如果您遇到任何问题或需要帮助，请联系我们的客服团队，他们将很乐意为您提供支持。\n'
                    '    感谢您的配合！我们期待着为您提供优质的服务和精彩的用户体验。\n'
                    '        ————济知音\n',
            from_email='15044154828@163.com',
            recipient_list=[email],
        )

        expiration = timezone.now() + timedelta(minutes=5)
        try:
            verify = Verification.objects.get(email=email)
        except Verification.DoesNotExist:
            Verification.objects.create(email=email, code=code, expiration=expiration)
        else:
            verify.code = code
            verify.expiration = expiration
            verify.save()
        return FormatResponse()

    # /account/update_password/
    @action(methods=['post'], detail=False, permission_classes=[])
    def update_password(self, request):
        serializer = PasswordSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        email = serializer.validated_data['email']
        code = serializer.validated_data['code']
        password = serializer.validated_data['password']
        try:
            user = UserProfile.objects.get(email=email)
        except UserProfile.DoesNotExist:
            raise ValidationError('不存在使用该邮箱的用户')
        check_verification(email, code)
        user.set_password(password)
        user.save()
        return FormatResponse()
