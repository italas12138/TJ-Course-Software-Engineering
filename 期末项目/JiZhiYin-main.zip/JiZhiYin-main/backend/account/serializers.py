from rest_framework import serializers
from rest_framework.exceptions import ValidationError

from account.models import UserProfile, UserGroup
from utils.models import UploadFile, Tag
from utils.utility import primary_key_serializer


class RegisterSerializer(serializers.Serializer):
    username = serializers.CharField(max_length=150)
    password = serializers.CharField(max_length=128)
    email = serializers.EmailField()
    code = serializers.CharField(max_length=50)


class MedalSerializer(serializers.ModelSerializer):
    url = serializers.FileField(source='image_file.file', read_only=True)

    class Meta:
        model = UserGroup
        fields = ['id', 'name', 'url']


class UserSelfSerializer(serializers.ModelSerializer):
    medal_group = MedalSerializer(read_only=True)
    image_url = serializers.FileField(source='image_file.file', read_only=True, allow_null=True)
    prefer_tags = serializers.SlugRelatedField(slug_field='name', many=True, read_only=True)

    class Meta:
        model = UserProfile
        fields = ['id', 'username', 'email', 'nickname', 'description', 'is_musician',
                  'is_staff', 'is_superuser', 'medal_group', 'image_url', 'prefer_tags']


UserPkSerializer = primary_key_serializer('user_id', 'user', UserProfile)


class UserOtherSerializer(serializers.ModelSerializer):
    medal_group = MedalSerializer(read_only=True)
    image_url = serializers.FileField(source='image_file.file', read_only=True, allow_null=True)

    class Meta:
        model = UserProfile
        fields = ['id', 'username', 'email', 'nickname', 'description',
                  'is_musician', 'medal_group', 'image_url']


class UserUpdateSerializer(serializers.ModelSerializer):
    medal_group_id = serializers.PrimaryKeyRelatedField(source='medal_group', allow_null=True,
                                                        queryset=UserGroup.objects.all())
    image_file_id = serializers.PrimaryKeyRelatedField(source='image_file', queryset=UploadFile.objects.all())
    prefer_tags = serializers.SlugRelatedField(slug_field='name', queryset=Tag.objects.all(),
                                               many=True, allow_empty=True)

    class Meta:
        model = UserProfile
        fields = ['nickname', 'description', 'medal_group_id', 'image_file_id', 'prefer_tags']

    def validate_medal_group_id(self, value):
        user = self.context['request'].user
        if value is not None and not user.groups.filter(pk=value.pk).exists():
            raise ValidationError('无法将未加入的组设为勋章')
        return value

    def validate_image_file_id(self, value):
        user = self.context['request'].user
        if value is not None and value.user != user:
            raise ValidationError('无法将其他用户上传的图片作为头像')
        return value


class VerifySerializer(serializers.Serializer):
    email = serializers.EmailField()


class PasswordSerializer(serializers.Serializer):
    password = serializers.CharField(max_length=128)
    email = serializers.EmailField()
    code = serializers.CharField(max_length=50)
