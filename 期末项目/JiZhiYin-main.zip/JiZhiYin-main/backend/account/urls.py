from django.urls import path, include
from account.views import AccountViewSet
from utils.utility import ActionRouter

router = ActionRouter()
router.register(r'', AccountViewSet, basename='account')

urlpatterns = [
    path('', include(router.urls))
]
