from datetime import timezone

from django.db import models
from django.contrib.auth.models import AbstractUser


# Create your models here.
class UserGroup(models.Model):
    name = models.CharField(max_length=150)
    description = models.TextField()
    owner = models.ForeignKey('UserProfile', on_delete=models.CASCADE)
    count = models.IntegerField(default=0)
    image_file = models.OneToOneField('utils.UploadFile', on_delete=models.SET_NULL, null=True, blank=True)


class UserProfile(AbstractUser):
    email = models.EmailField(unique=True)
    nickname = models.CharField(max_length=150)
    description = models.TextField(blank=True)
    is_musician = models.BooleanField(default=False)
    medal_group = models.ForeignKey(UserGroup, on_delete=models.SET_NULL, null=True, blank=True)
    image_file = models.OneToOneField('utils.UploadFile', on_delete=models.SET_NULL, null=True, blank=True)
    groups = models.ManyToManyField(UserGroup, related_name='members')
    friends = models.ManyToManyField('self')
    show_blogs = models.ManyToManyField('blog.Blog', related_name='shown_users')
    prefer_tags = models.ManyToManyField('utils.Tag', related_name='prefer_users')


class Verification(models.Model):
    email = models.EmailField(unique=True)
    code = models.CharField(max_length=50)
    expiration = models.DateTimeField()
