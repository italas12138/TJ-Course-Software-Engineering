from django.urls import path, include
from comment.views import CommentViewSet
from utils.utility import ActionRouter

router = ActionRouter()
router.register(r'', CommentViewSet, basename='comment')

urlpatterns = [
    path('', include(router.urls))
]
