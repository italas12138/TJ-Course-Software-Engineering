from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.exceptions import PermissionDenied
from rest_framework.permissions import IsAuthenticated

from utils.utility import FormatResponse
from comment.models import Comment

from comment.serializers import BlogPkSerializer, CommentDetailSerializer, CommentSubmitSerializer, CommentPkSerializer


# Create your views here
class CommentViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]

    # /comment/list/
    @action(methods=['post'], detail=False)
    def list(self, request):
        serializer = BlogPkSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        blog = serializer.validated_data['blog']
        comment_serializer = CommentDetailSerializer(
            instance=Comment.objects.filter(blog=blog),
            many=True,
            context={'request': request}
        )

        return FormatResponse(data={
            'comments': comment_serializer.data
        })

    # /comment/submit/
    @action(methods=['post'], detail=False)
    def submit(self, request):
        serializer = CommentSubmitSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        comment = serializer.save(author=request.user)
        submit_serializer = CommentDetailSerializer(instance=comment, context={'request': request})
        return FormatResponse(data=submit_serializer.data)

    # /comment/delete/
    @action(methods=['post'], detail=False)
    def delete(self, request):
        serializer = CommentPkSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        comment = serializer.validated_data['comment']

        if comment.author != request.user:
            raise PermissionDenied('无法删除不是自己发布的评论')

        comment.delete()
        return FormatResponse()
