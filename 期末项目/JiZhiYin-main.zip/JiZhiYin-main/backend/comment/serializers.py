from rest_framework import serializers
from rest_framework.exceptions import PermissionDenied

from utils.utility import primary_key_serializer

from account.models import UserProfile
from blog.models import Blog
from comment.models import Comment

BlogPkSerializer = primary_key_serializer('blog_id', 'blog', Blog)


class UserCommentSerializer(serializers.ModelSerializer):
    image_url = serializers.FileField(source='image_file.file', read_only=True, allow_null=True)

    class Meta:
        model = UserProfile
        fields = ['id', 'nickname', 'image_url']


class CommentDetailSerializer(serializers.ModelSerializer):
    parent_comment_id = serializers.PrimaryKeyRelatedField(source='parent_comment', read_only=True, allow_null=True)
    author = UserCommentSerializer()

    class Meta:
        model = Comment
        fields = ['id', 'parent_comment_id', 'author', 'content', 'timestamp']


class CommentSubmitSerializer(serializers.ModelSerializer):
    blog_id = serializers.PrimaryKeyRelatedField(source='blog', queryset=Blog.objects.all())
    parent_comment_id = serializers.PrimaryKeyRelatedField(source='parent_comment', queryset=Comment.objects.all(),
                                                           allow_null=True)

    class Meta:
        model = Comment
        fields = ['blog_id', 'parent_comment_id', 'content']

    def validate(self, attrs):
        blog = attrs.get('blog')
        parent_comment = attrs.get('parent_comment')
        if parent_comment is not None and parent_comment.blog.pk != blog.pk:
            raise PermissionDenied('属于不同帖子下的评论无法建立嵌套关系')
        return attrs


CommentPkSerializer = primary_key_serializer('comment_id', 'comment', Comment)
