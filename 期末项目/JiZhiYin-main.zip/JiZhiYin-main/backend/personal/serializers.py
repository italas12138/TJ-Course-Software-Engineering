from rest_framework import serializers
from rest_framework.exceptions import PermissionDenied

from account.models import UserProfile
from blog.models import Blog


class ShowUpdateSerializer(serializers.ModelSerializer):
    show_blogs_id = serializers.PrimaryKeyRelatedField(source='show_blogs', many=True,
                                                       queryset=Blog.objects.all())

    class Meta:
        model = UserProfile
        fields = ['show_blogs_id']

    def validate_show_blogs_id(self, value):
        user = self.context['request'].user
        for blog in value:
            if blog.author != user:
                raise PermissionDenied('无法展示其他用户发布的帖子')
        return value
