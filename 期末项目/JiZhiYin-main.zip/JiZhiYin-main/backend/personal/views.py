from random import sample
from django.db.models import Count, Q, F, Max
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated

from account.serializers import UserPkSerializer
from blog.models import Blog
from blog.serializers import NormalSerializer
from personal.serializers import ShowUpdateSerializer
from utils.utility import FormatResponse


# Create your views here.

class PersonalListViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]

    # /personal/list/published/
    @action(methods=['post'], detail=False)
    def published(self, request):
        serializer = UserPkSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = serializer.validated_data['user']
        blog_serializer = NormalSerializer(instance=Blog.objects.filter(author=user), many=True,
                                           context={'request': request})
        return FormatResponse(data={
            'blogs': blog_serializer.data
        })

    # /personal/list/shown/
    @action(methods=['post'], detail=False)
    def shown(self, request):
        serializer = NormalSerializer(instance=request.user.show_blogs.all(), many=True,
                                      context={'request': request})
        return FormatResponse(data={
            'blogs': serializer.data
        })

    # /personal/list/collected/
    @action(methods=['post'], detail=False)
    def collected(self, request):
        blog_serializer = NormalSerializer(instance=request.user.collect_blogs.all(), many=True,
                                           context={'request': request})
        return FormatResponse(data={
            'blogs': blog_serializer.data
        })

    # /personal/list/recommend/
    @action(methods=['post'], detail=False)
    def recommend(self, request):
        user_tags = request.user.prefer_tags.all()
        tag_count = user_tags.count()
        recommend_blogs = Blog.objects.annotate(tag_score=Count('tags', filter=Q(tags__in=user_tags)) / tag_count) \
                              .annotate(like_score=F('like_count') / Max('like_count')) \
                              .annotate(collect_score=F('collect_count') / Max('collect_count')) \
                              .annotate(score=F('tag_score') + F('tag_score') + F('collect_score')) \
                              .order_by('-score')[:100]
        recommend_blogs = sample(list(recommend_blogs), min(recommend_blogs.count(), 20))
        serializer = NormalSerializer(instance=recommend_blogs, many=True, context={'request': request})
        return FormatResponse(data={
            'blogs': serializer.data
        })


class PersonalUpdateViewSet(viewsets.ViewSet):
    permission_classes = [IsAuthenticated]

    # /personal/update/shown/
    @action(methods=['post'], detail=False)
    def shown(self, request):
        serializer = ShowUpdateSerializer(instance=request.user, data=request.data, context={'request': request})
        serializer.is_valid(raise_exception=True)
        serializer.save()
        show_serializer = NormalSerializer(instance=request.user.show_blogs.all(), many=True,
                                           context={'request': request})
        return FormatResponse(data={
            'blogs': show_serializer.data
        })
