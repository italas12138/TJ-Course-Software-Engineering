from django.urls import path, include
from personal.views import PersonalListViewSet, PersonalUpdateViewSet
from utils.utility import ActionRouter

router = ActionRouter()
router.register(r'list', PersonalListViewSet, basename='personal-list')
router.register(r'update', PersonalUpdateViewSet, basename='personal-update')

urlpatterns = [
    path('', include(router.urls))
]
